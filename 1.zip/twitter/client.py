#twitter/client.py
from typing import Any, Literal, Iterable
from time import time
import asyncio
import base64
import json
import re

from loguru import logger
from curl_cffi import requests
from yarl import URL

from .errors import (
    TwitterException,
    FailedToFindDuplicatePost,
    HTTPException,
    BadRequest,
    Unauthorized,
    Forbidden,
    NotFound,
    RateLimited,
    ServerError,
)
from .base import BaseHTTPClient
from .account import Account
from .models import User, Tweet, Media
from .utils import (
    tweets_data_from_instructions,
)

class Client(BaseHTTPClient):
    _BASE_FEATURES = {
        # Core features
        "verified_phone_label_enabled": True,
        "super_follow_badge_privacy_enabled": True,
        "subscriptions_verification_info_enabled": True,
        "super_follow_user_api_enabled": True,
        "blue_business_profile_image_shape_enabled": True,
        "immersive_video_status_linkable_timestamps": True,
        "super_follow_exclusive_tweet_notifications_enabled": True,
        
        # API features
        "articles_api_enabled": True,
        "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
        "longform_notetweets_consumption_enabled": True,
        "tweetypie_unmention_optimization_enabled": True,
        "longform_notetweets_rich_text_read_enabled": True,
        "android_graphql_skip_api_media_color_palette": True,
        "creator_subscriptions_tweet_preview_api_enabled": True,
        "unified_cards_ad_metadata_container_dynamic_card_content_query_enabled": True,
        "longform_notetweets_inline_media_enabled": True,
        "freedom_of_speech_not_reach_fetch_enabled": True,
        "super_follow_tweet_api_enabled": True,
        
        # Web features
        "responsive_web_graphql_exclude_directive_enabled": True,
        "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
        "responsive_web_graphql_timeline_navigation_enabled": True,
        "standardized_nudges_misinfo": True,
        "tweet_awards_web_tipping_enabled": False,
        "c9s_tweet_anatomy_moderator_badge_enabled": True,
        "responsive_web_enhance_cards_enabled": False,
        "responsive_web_twitter_article_tweet_consumption_enabled": True,
        "responsive_web_edit_tweet_api_enabled": True,
        "view_counts_everywhere_api_enabled": True,
        
        # Additional required features
        "rweb_lists_timeline_redesign_enabled": True,
        "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
        "responsive_web_twitter_blue_verified_badge_is_enabled": True,
        "highlights_tweets_tab_ui_enabled": True,
    }

    def _get_features(self, additional_features: dict = None) -> dict:
        """Get base features with optional additional features"""
        features = self._BASE_FEATURES.copy()
        if additional_features:
            features.update(additional_features)
        return features
    
    _DEFAULT_HEADERS = {
        "Host": "api.twitter.com",
        # "Cookie": "guest_id_marketing=v1%3A173143530674266480; guest_id_ads=v1%3A173143530674266480; personalization_id=v1_ek1Fq00lMUSd+tYH8lIClQ==; guest_id=v1%3A173143530674266480; lang=en",
        "Timezone": "Asia/Calcutta",
        "Os-Security-Patch-Level": "2018-08-05",
        "Optimize-Body": "true",
        "Accept": "application/json",
        "X-Twitter-Client": "TwitterAndroid",
        "X-Attest-Token": "no_token",
        "User-Agent": "TwitterAndroid/10.48.0-release.0 (310480000) SM-S918U1/14 (samsung;SM-S918U1;samsung;zgfcaa;0;;11;230905)",
        # "X-Twitter-Client-Adid": "ef6f5023-25bb-4764-957b-861eb33661fd",
        "Accept-Encoding": "gzip, deflate, br",
        "X-Twitter-Client-Language": "en-US",
        # "X-Client-Uuid": "e973305b-c447-4a39-a90b-2b31e2441443",
        # "X-Twitter-Client-Deviceid": "c0f4a20965448dc6",
        "X-Twitter-Client-Version": "10.57.0-release.0",
        "Cache-Control": "no-store",
        "X-Twitter-Active-User": "yes",
        "X-Twitter-Api-Version": "5",
        # "Kdt": "6DFRUpa6dNuXZLQ99kypSuCDvdcAFKhq0x35MG48",
        "X-Twitter-Client-Limit-Ad-Tracking": "0",
        # "X-B3-Traceid": "92c7ef64fce38fc2",
        "Accept-Language": "en-US",
        "X-Twitter-Client-Flavor": ""
    }

    _GRAPHQL_URL = "https://api.twitter.com/graphql"
    _ACTION_TO_QUERY_ID = {
        "CreateRetweet": "ojPdsZsimiJrUGLR1sjUtA",
        "FavoriteTweet": "lI07N6Otwv1PhnEgXILM7A",
        "UnfavoriteTweet": "ZYKSe-w7KEslx3JhSIk5LA",
        "CreateTweet": "oB-5XsHNAbjvARJEc8CZFw",
        "TweetResultByRestId": "V3vfsYzNEyD9tsf4xoFRgw",
        "ModerateTweet": "p'jF:GVqCjTcZol0xcBJjw",
        "DeleteTweet": "VaenaVgh5q5ih7kvyVjgtg",
        "UserTweets": "V1ze5q3ijDS1VeLwLY0m7g",
        "TweetDetail": "MdM6P_0z37tPVjUmvmKgCQ",
        "ProfileSpotlightsQuery": "9zwVLJ48lmVUk8u_Gh9DmA",
        "Following": "t-BPOrMIduGUJWO_LxcvNQ",
        "Followers": "3yX7xr2hKjcZYnXt6cU6lQ",
        "UserByScreenName": "G3KGOASz96M-Qu0nwmGXNg",
        "UsersByRestIds": "itEhGywpgX9b3GJCzOtSrA",
        "Viewer": "-876iyxD1O_0X0BqeykjZA",
        "PinTweet": "VIHsNu89pK-kW35JpHq7Xw",  # Add this line
        "TweetResultByIdQuery": "MkzGRJm2Z6kI3-q13jd8Wg",
        "UserWithProfileTweetsQueryV2": "CIpxU9ghNmicVWLbvSnNYQ",
        "UserResultByIdQuery": "iOA9WG49OYDPdIvJi4K7Yw",
        "ConversationTimelineV2": "06SnqRrS9J_ZKzl5Dn4uIg",
        "HomeTimeline": "Iaj4kAIobIAtigNaYNIOAw"
    }

    @classmethod
    def _action_to_url(cls, action: str) -> tuple[str, str]:
        """
        :return: URL and Query ID
        """
        query_id = cls._ACTION_TO_QUERY_ID[action]
        url = f"{cls._GRAPHQL_URL}/{query_id}/{action}"
        return url, query_id

    def __init__(
        self,
        auth,
        account: Account = None,
        *,
        wait_on_rate_limit: bool = True,
        update_account_info_on_startup: bool = True,
        **session_kwargs,
    ):
        super().__init__(**session_kwargs)
        self.auth = auth
        self.account = account
        self.wait_on_rate_limit = wait_on_rate_limit
        self._update_account_info_on_startup = update_account_info_on_startup

    async def __aenter__(self):
        await self.on_startup()
        return await super().__aenter__()

    async def _request(
        self,
        method,
        url,
        *,
        auth: bool = True,
        wait_on_rate_limit: bool = None,
        **kwargs,
    ) -> tuple[requests.Response, Any]:
        headers = kwargs["headers"] = kwargs.get("headers", {})
        headers.update(self._DEFAULT_HEADERS)

        # Ensure content-type is set for POST requests
        if method.upper() == 'POST':
            headers['Content-Type'] = 'application/json'

        if auth:
            # Get OAuth1 headers and update request headers
            params = kwargs.get('params', {})
            if isinstance(params, dict):
                auth_headers = self.auth.get_auth_headers(method, url, params)
                headers.update(auth_headers)

        # Convert any json payload to string to ensure proper formatting
        if 'json' in kwargs:
            kwargs['data'] = json.dumps(kwargs.pop('json'))

        log_message = f"Request {method} {url}"
        if kwargs.get('data'): log_message += f"\nRequest data: {kwargs.get('data')}"
        logger.debug(log_message)

        try:
            response = await self._session.request(method, url, **kwargs)
        except requests.errors.RequestsError as exc:
            if exc.code == 35:
                msg = (
                    "The IP address may have been blocked by Twitter. "
                    "Blocked countries: Russia. " + str(exc)
                )
                raise requests.errors.RequestsError(msg, 35, exc.response)
            raise

        data = response.text
        logger.debug(f"Response {method} {url}"
                    f"\nStatus code: {response.status_code}"
                    f"\nResponse data: {data}")

        try:
            data = response.json()
        except json.decoder.JSONDecodeError:
            pass

        if 300 > response.status_code >= 200:
            if isinstance(data, dict) and "errors" in data:
                raise HTTPException(response, data)
            return response, data

        if response.status_code == 400:
            raise BadRequest(response, data)

        if response.status_code == 401:
            raise Unauthorized(response, data)

        if response.status_code == 403:
            raise Forbidden(response, data)

        if response.status_code == 404:
            raise NotFound(response, data)

        if response.status_code == 429:
            if wait_on_rate_limit is None:
                wait_on_rate_limit = self.wait_on_rate_limit
            if not wait_on_rate_limit:
                raise RateLimited(response, data)

            reset_time = int(response.headers["x-rate-limit-reset"])
            sleep_time = reset_time - int(time()) + 1
            if sleep_time > 0:
                logger.warning(f"Rate limited! Sleep time: {sleep_time} sec.")
                await asyncio.sleep(sleep_time)
            return await self._request(
                method,
                url,
                auth=auth,
                wait_on_rate_limit=wait_on_rate_limit,
                **kwargs,
            )

        if response.status_code >= 500:
            raise ServerError(response, data)

    async def request(
        self,
        method,
        url,
        **kwargs,
    ) -> tuple[requests.Response, Any]:
        return await self._request(method, url, **kwargs)

    async def on_startup(self):
        if self._update_account_info_on_startup and self.account:
            await self.update_account_info()

    async def update_account_info(self):
        """Update account information using both REST and GraphQL APIs"""
        if not self.account:
            return
            
        if not self.account.username:
            # Get user info from REST API
            url = "https://api.twitter.com/1.1/account/verify_credentials.json"
            response, data = await self.request("GET", url)
            self.account.username = data["screen_name"]
            self.account.id = data["id"]
            
        # Get full user details from GraphQL
        if self.account.username:
            user = await self.request_user_by_username(self.account.username)
            if user:
                self.account.update(**user.dict())

    # GraphQL Methods
    async def _request_user_by_username(self, username: str) -> User | None:
        """Request user information using GraphQL"""
        url, query_id = self._action_to_url("UserByScreenName")
        variables = {
            "screen_name": username,
            "withSafetyModeUserFields": True,
        }
        features = {
            "hidden_profile_likes_enabled": True,
            "hidden_profile_subscriptions_enabled": True,
            "responsive_web_graphql_exclude_directive_enabled": True,
            "verified_phone_label_enabled": False,
            "highlights_tweets_tab_ui_enabled": True,
            "creator_subscriptions_tweet_preview_api_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
        }
        params = {
            "variables": variables,
            "features": features,
        }
        response, data = await self.request("GET", url, params=params)
        print(response, data)
        if not data["data"]:
            return None
        return User.from_raw_data(data["data"]["user"]["result"])

    async def request_user_by_username(self, username: str) -> User | None:
        """Get user information (tries GraphQL first, falls back to REST)"""
        try:
            return await self._request_user_by_username(username)
        except HTTPException as e:
            # Fallback to REST API if GraphQL fails
            url = f"https://api.twitter.com/1.1/users/show.json"
            params = {"screen_name": username}
            try:
                response, data = await self.request("GET", url, params=params)
                print(response, data)
                return User.from_raw_data({"rest_id": data["id"], "legacy": data})
            except NotFound:
                return None

    # Tweet Methods
    #twitter/client.py - Update the tweet method

    async def tweet(
        self,
        text: str,
        *,
        media_id: int | str = None,
        search_duplicate: bool = True,
    ) -> Tweet:
        """Post a new tweet (using GraphQL)"""
        url, query_id = self._action_to_url("CreateTweet")
        variables = {
            "tweet_text": text,
            "dark_request": False,
            "media": {"media_entities": [], "possibly_sensitive": False},
            "semantic_annotation_ids": [],
        }
        if media_id:
            variables["media"]["media_entities"].append(
                {"media_id": str(media_id), "tagged_users": []}
            )
        
        features = {
            "responsive_web_twitter_article_tweet_consumption_enabled": True,
            "longform_notetweets_inline_media_enabled": True,
            "creator_subscriptions_quote_tweet_preview_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "view_counts_everywhere_api_enabled": True,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "tweet_awards_web_tipping_enabled": True,
            "tweetypie_unmention_optimization_enabled": True,
            "rweb_tipjar_consumption_enabled": True,
            "c9s_tweet_anatomy_moderator_badge_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_edit_tweet_api_enabled": True,
            "verified_phone_label_enabled": False,
            "rweb_video_timestamps_enabled": True,
            "communities_web_enable_tweet_community_results_fetch": True,
            "responsive_web_graphql_exclude_directive_enabled": True,
            "freedom_of_speech_not_reach_fetch_enabled": True,
            "responsive_web_enhance_cards_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
            "longform_notetweets_rich_text_read_enabled": True,
            "standardized_nudges_misinfo": True,
            "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
            "articles_preview_enabled": True
        }

        payload = {
            "variables": variables,
            "features": features,
            "queryId": query_id,
        }
        
        response, data = await self.request("POST", url, json=payload)
        
        try:
            logger.debug(f"Tweet response data: {json.dumps(data, indent=2)}")
            
            result = data.get("data", {}).get("create_tweet", {}).get("tweet_results", {}).get("result", {})
            
            if not result:
                # Fallback to REST API to get tweet info
                try:
                    tweet_id = data["data"]["create_tweet"]["tweet_results"]["result"]["rest_id"]
                    tweet = await self._request_tweet(tweet_id)
                    logger.info(f"Successfully created tweet: {tweet.url}")
                    return tweet
                except Exception as e:
                    logger.error(f"Failed to fetch tweet details: {e}")
                    raise TwitterException("Tweet was created but failed to fetch details") from e
            
            tweet = Tweet.from_raw_data(result)
            logger.info(f"Successfully created tweet: {tweet.url}")
            return tweet
            
        except Exception as e:
            logger.error(f"Error parsing tweet response: {e}\nResponse data: {data}")
            # If we got here, the tweet might have been created but we failed to parse the response
            raise TwitterException(f"Error parsing tweet response: {e}") from e

    # Add a helper method to get tweet by ID using REST API
    async def _request_tweet_rest(self, tweet_id: int | str) -> Tweet:
        """Request tweet information using REST API"""
        url = f"https://api.twitter.com/1.1/statuses/show.json"
        params = {
            "id": str(tweet_id),
            "tweet_mode": "extended"
        }
        response, data = await self.request("GET", url, params=params)
        # Convert REST API response format to GraphQL format
        converted_data = {
            "rest_id": str(data["id"]),
            "legacy": data,
            "core": {
                "user_results": {
                    "result": {
                        "rest_id": str(data["user"]["id"]),
                        "legacy": data["user"]
                    }
                }
            }
        }
        return Tweet.from_raw_data(converted_data)

    async def upload_image(
        self,
        image: bytes,
        attempts: int = 3,
        timeout: float | tuple[float, float] = 10,
    ) -> Media:
        """Upload media to Twitter"""
        url = "https://upload.twitter.com/1.1/media/upload.json"
        payload = {"media_data": base64.b64encode(image).decode('utf-8')}
        
        for attempt in range(attempts):
            try:
                response, data = await self.request(
                    "POST", url, data=payload, timeout=timeout
                )
                return Media(**data)
            except (HTTPException, requests.errors.RequestsError) as exc:
                if (
                    attempt < attempts - 1
                    and (
                        isinstance(exc, requests.errors.RequestsError)
                        and exc.code == 28
                    )
                    or (
                        isinstance(exc, HTTPException)
                        and exc.response.status_code == 408
                    )
                ):
                    continue
                else:
                    raise
    
    #twitter/client.py - Add these methods to the Client class

    async def pin_tweet(self, tweet_id: str | int) -> bool:
        """
        Pin a tweet to your profile using GraphQL
        
        Args:
            tweet_id: The ID of the tweet to pin
            
        Returns:
            bool: True if the tweet was successfully pinned
        """
        url, query_id = self._action_to_url("PinTweet")
        
        payload = {
            "variables": {
                "tweet_id": str(tweet_id)
            },
            "queryId": query_id
        }
        
        try:
            response, data = await self.request("POST", url, json=payload)
            result = data.get("data", {}).get("pin_tweet")
            return bool(result)
        except Exception as e:
            logger.error(f"Failed to pin tweet {tweet_id}: {e}")
            return False

    async def update_profile(
        self,
        name: str = None,
        description: str = None,
        location: str = None,
        website: str = None,
    ) -> bool:
        """
        Update profile information
        Note: This operation may lock the account!
        """
        if name is None and description is None and location is None and website is None:
            raise ValueError("Specify at least one parameter to update")

        url = "https://api.twitter.com/1.1/account/update_profile.json"
        payload = {
            k: v
            for k, v in [
                ("name", name),
                ("description", description),
                ("location", location),
                ("url", website),
            ]
            if v is not None
        }
        response, data = await self.request("POST", url, data=payload)
        
        # Verify updates
        updated = all(
            data.get(key) == value for key, value in payload.items() if key != "url"
        )
        if website:
            updated &= website == data["entities"]["url"]["urls"][0]["expanded_url"]
        
        await self.update_account_info()
        return updated

    async def update_birthdate(
        self,
        day: int,
        month: int,
        year: int,
        visibility: Literal["self", "mutualfollow"] = "self",
        year_visibility: Literal["self"] = "self",
    ) -> bool:
        """Update account birthdate"""
        url = "https://api.twitter.com/1.1/account/update_profile.json"
        payload = {
            "birthdate_day": day,
            "birthdate_month": month,
            "birthdate_year": year,
            "birthdate_visibility": visibility,
            "birthdate_year_visibility": year_visibility,
        }
        response, response_json = await self.request("POST", url, json=payload)
        birthdate_data = response_json["extended_profile"]["birthdate"]
        updated = all(
            (
                birthdate_data["day"] == day,
                birthdate_data["month"] == month,
                birthdate_data["year"] == year,
                birthdate_data["visibility"] == visibility,
                birthdate_data["year_visibility"] == year_visibility,
            )
        )
        return updated

    async def get_user_profile_tweets(self, user_id: str | int) -> list[Tweet]:
        """
        Get user's profile tweets using UserWithProfileTweetsQueryV2
        """
        url, query_id = self._action_to_url("UserWithProfileTweetsQueryV2")
        
        variables = {
            "rest_id": str(user_id),
            "count": 40,
            "includePromotedContent": True,
            "withQuickPromoteEligibilityTweetFields": True,
            "withVoice": True,
            "withV2Timeline": True,
            "withBirdwatchNotes": True,
            "withDownvotePerspective": False,
            "withReactionsMetadata": False,
            "withReactionsPerspective": False,
            "withSuperFollowsTweetFields": True,
            "withSuperFollowsUserFields": True,
        }
        
        features = self._get_features({
            "unified_cards_ad_metadata_container_dynamic_card_content_query_enabled": True,
            "super_follow_tweet_api_enabled": True,
            "responsive_web_twitter_article_tweet_consumption_enabled": True,
        })
        
        payload = {
            "variables": variables,
            "features": features,
            "queryId": query_id,
        }
        
        # Debug logging
        logger.debug(f"Request payload: {json.dumps(payload, indent=2)}")
        
        response, data = await self.request("POST", url, json=payload)
        print(response.headers)
        tweets = []
        try:
            if "data" in data and "user_result" in data["data"]:
                timeline_response = data["data"]["user_result"]["result"]["timeline_response"]
                if "timeline" in timeline_response:
                    instructions = timeline_response["timeline"]["instructions"]
                    for instruction in instructions:
                        # Skip cache clear
                        if instruction["__typename"] == "TimelineClearCache":
                            continue

                        # Handle pinned tweet
                        if instruction["__typename"] == "TimelinePinEntry":
                            try:
                                if (instruction["entry"]["content"]["content"]["tweetResult"]["result"]):
                                    tweet_data = instruction["entry"]["content"]["content"]["tweetResult"]["result"]
                                    tweet = Tweet.from_raw_data(tweet_data)
                                    tweet.pinned = True
                                    tweets.append(tweet)
                            except Exception as e:
                                logger.warning(f"Failed to parse pinned tweet: {e}")
                        
                        # Handle timeline tweets
                        elif instruction["__typename"] == "TimelineAddEntries":
                            for entry in instruction["entries"]:
                                try:
                                    # Skip cursor entries
                                    if not entry["entryId"].startswith("tweet-"):
                                        continue
                                        
                                    # Check for tweet in different possible locations
                                    tweet_data = None
                                    if "content" in entry:
                                        if "itemContent" in entry["content"]:
                                            if "tweet_results" in entry["content"]["itemContent"]:
                                                tweet_data = entry["content"]["itemContent"]["tweet_results"]["result"]
                                        elif "content" in entry["content"]:
                                            if "tweetResult" in entry["content"]["content"]:
                                                tweet_data = entry["content"]["content"]["tweetResult"]["result"]
                                    
                                    if tweet_data:
                                        tweet = Tweet.from_raw_data(tweet_data)
                                        # Add social context if present
                                        if "tweetDisplayType" in entry["content"]:
                                            tweet.display_type = entry["content"]["tweetDisplayType"]
                                        if "socialContext" in entry["content"]:
                                            tweet.social_context = entry["content"]["socialContext"].get("text")
                                        tweets.append(tweet)
                                except Exception as e:
                                    logger.warning(f"Failed to parse tweet in entry {entry.get('entryId')}: {e}")
                                    continue
                                    
            return tweets

        except Exception as e:
            logger.error(f"Error parsing timeline data: {e}\nData: {json.dumps(data, indent=2)}")
            raise TwitterException(f"Failed to parse timeline data: {e}")


    async def get_user_by_id(self, user_id: str | int) -> User:
        """
        Get user details using UserResultByIdQuery
        """
        url, query_id = self._action_to_url("UserResultByIdQuery")
        
        variables = {
            "include_smart_block": True,
            "includeTweetImpression": True,
            "include_profile_info": True,
            "includeTranslatableProfile": True,
            "includeHasBirdwatchNotes": False,
            "include_tipjar": True,
            "includeEditPerspective": False,
            "include_reply_device_follow": True,
            "includeEditControl": True,
            "include_verified_phone_status": True,
            "rest_id": str(user_id)
        }
        
        features = self._get_features({
            "verified_phone_label_enabled": True,
            "super_follow_badge_privacy_enabled": True,
            "subscriptions_verification_info_enabled": True,
            "super_follow_user_api_enabled": True,
            "blue_business_profile_image_shape_enabled": True,
            "immersive_video_status_linkable_timestamps": True,
            "super_follow_exclusive_tweet_notifications_enabled": True,
            "responsive_web_graphql_exclude_directive_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
        })
        
        params = {
            "variables": variables,
            "features": features
        }
        
        headers = {
            "Content-Type": "application/json",
            "X-Twitter-Active-User": "yes",
            "X-Twitter-Client-Language": "en",
            "X-Twitter-Client": "TwitterAndroid",
        }
        
        response, data = await self.request(
            "GET", 
            url, 
            params=params,
            headers=headers
        )
        
        if not data or "data" not in data:
            raise TwitterException(f"Failed to fetch user {user_id}")
            
        user_data = data["data"].get("user", {}).get("result")
        if not user_data:
            return None
            
        return User.from_raw_data(user_data)

    async def _request_users_by_ids(self, user_ids: Iterable[str | int]) -> dict[int, User]:
        """Request multiple users by IDs"""
        url, query_id = self._action_to_url("UsersByRestIds")
        
        variables = {
            "userIds": [str(user_id) for user_id in user_ids],
            "withSafetyModeUserFields": True,
        }
        
        features = self._get_features({
            "responsive_web_graphql_exclude_directive_enabled": True,
            "verified_phone_label_enabled": False,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True
        })
        
        params = {
            "variables": variables,
            "features": features,
        }
        
        headers = {
            "Content-Type": "application/json",
            "X-Twitter-Active-User": "yes",
            "X-Twitter-Client-Language": "en",
            "X-Twitter-Client": "TwitterAndroid",
        }
        
        response, data = await self.request(
            "GET", 
            url, 
            params=params,
            headers=headers
        )
        
        if not data or "data" not in data or "users" not in data["data"]:
            raise TwitterException("Failed to fetch users")

        users = {}
        for user_data in data["data"]["users"]:
            user = User.from_raw_data(user_data["result"])
            users[user.id] = user
            if user.id == self.account.id:
                users[self.account.id] = self.account
                
        return users

    async def get_tweet_detail(self, tweet_id: str | int) -> Tweet:
        """
        Get detailed tweet information using TweetDetail query.
        
        Args:
            tweet_id: ID of the tweet to fetch
            
        Returns:
            Tweet: Tweet object with full details and replies
        """
        url = f"{self._GRAPHQL_URL}/MdM6P_0z37tPVjUmvmKgCQ/TweetDetail"
        
        variables = {
            "focalTweetId": str(tweet_id),
            "cursor": None,
            "referrer": "profile",
            "controller_data": None,
            "includePromotedContent": True,
            "withSafetyModeUserFields": True,
            "withQuickPromoteEligibilityTweetFields": True,
            "withVoice": True,
            "withV2Timeline": True,
            "withDownvotePerspective": False,
            "withBirdwatchNotes": True,
            "withCommunity": True,
            "withSuperFollowsUserFields": True,
            "withReactionsMetadata": False,
            "withReactionsPerspective": False,
            "withSuperFollowsTweetFields": True,
            "isMetatagsQuery": False,
            "withReplays": True,
            "withClientEventToken": False,
            "withAttachments": True,
            "withConversationQueryHighlights": True,
            "withMessageQueryHighlights": True,
            "withMessages": True,
        }
        
        features = {
            "responsive_web_twitter_blue_verified_badge_is_enabled": True,
            "verified_phone_label_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
            "view_counts_everywhere_api_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "tweetypie_unmention_optimization_enabled": True,
            "responsive_web_edit_tweet_api_enabled": True,
            "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
            "freedom_of_speech_not_reach_fetch_enabled": True,
            "standardized_nudges_misinfo": True,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_graphql_exclude_directive_enabled": True,
            "responsive_web_enhance_cards_enabled": False,
            "longform_notetweets_rich_text_read_enabled" : True,
            "creator_subscriptions_tweet_preview_api_enabled" : True,
            "communities_web_enable_tweet_community_results_fetch" : True,
            "responsive_web_twitter_article_tweet_consumption_enabled" : True,
            "rweb_tipjar_consumption_enabled" : True,
            "responsive_web_live_screen_enabled" : True,
            "creator_subscriptions_quote_tweet_preview_enabled" : True,
            "tweet_awards_web_tipping_enabled" : True,
            "articles_preview_enabled" : True,
            "c9s_tweet_anatomy_moderator_badge_enabled" : True,
            "longform_notetweets_inline_media_enabled" : True,
            "rweb_video_timestamps_enabled" : True,
        }

        # Use auth headers
        headers = {
            "x-twitter-client-language": "en",
            "x-twitter-active-user": "yes",
            "content-type": "application/json",
        }

        params = {
            "variables": json.dumps(variables),
            "features": json.dumps(features),
        }
        
        try:
            response, data = await self.request(
                "GET",
                url,
                params=params,
                headers=headers,
                auth=True
            )
            print(response, data)
            instructions = data["data"]["threaded_conversation_with_injections_v2"]["instructions"]
            focal_tweet = None
            replies = []
            
            for instruction in instructions:
                if instruction["type"] != "TimelineAddEntries":
                    continue
                    
                for entry in instruction["entries"]:
                    try:
                        # Check for tweet in entry content
                        content = entry.get("content", {})
                        if content.get("entryType") != "TimelineTimelineItem":
                            continue
                            
                        item_content = content.get("itemContent", {})
                        if item_content.get("itemType") != "TimelineTweet":
                            continue
                            
                        if "tweet_results" not in item_content:
                            continue
                            
                        tweet_result = item_content["tweet_results"]["result"]
                        
                        # Handle TweetWithVisibilityResults wrapper
                        if tweet_result.get("__typename") == "TweetWithVisibilityResults":
                            tweet_result = tweet_result["tweet"]
                        
                        # Create tweet object
                        tweet = Tweet.from_raw_data(tweet_result)
                        
                        # Check if this is the main tweet
                        if str(tweet.id) == str(tweet_id):
                            focal_tweet = tweet
                        else:
                            replies.append(tweet)
                            
                    except Exception as e:
                        logger.warning(f"Failed to parse entry {entry.get('entryId')}: {e}")
                        continue
                        
            if not focal_tweet:
                raise ValueError(f"Could not find tweet {tweet_id} in response")
                
            focal_tweet.replies = sorted(replies, key=lambda x: x.created_at)
            return focal_tweet
            
        except Exception as e:
            logger.error(f"Error fetching tweet details for {tweet_id}: {e}")
            raise TwitterException(f"Failed to fetch tweet details: {e}") from e

    async def request_users_by_ids(self, user_ids: Iterable[str | int]) -> dict[int, User]:
        """
        Get multiple users by their IDs.
        Returns a dictionary mapping user IDs to User objects.
        """
        return await self._request_users_by_ids(user_ids)

    async def request_user_by_id(self, user_id: int | str) -> User | None:
        """
        Get user by ID.
        Returns User object or None if user not found.
        """
        users = await self._request_users_by_ids([user_id])
        return users.get(int(user_id))

    async def get_conversation(self, tweet_id: str | int, cursor: str = None) -> list[Tweet]:
        """
        Get conversation (thread) using ConversationTimelineV2
        
        Args:
            tweet_id: The ID of the tweet to get conversation for
            cursor: Pagination cursor for loading more tweets
            
        Returns:
            list[Tweet]: List of tweets in the conversation
        """
        url, query_id = self._action_to_url("ConversationTimelineV2")
        
        variables = {
            "includeTweetImpression": True,
            "includeHasBirdwatchNotes": True,
            "includeEditPerspective": False,
            "includeEditControl": True,
            "includeCommunityTweetRelationship": True,
            "rest_id": str(tweet_id),
            "includeTweetVisibilityNudge": True
        }
        
        features = {
            "longform_notetweets_inline_media_enabled": True,
            "super_follow_badge_privacy_enabled": True,
            "longform_notetweets_rich_text_read_enabled": True,
            "super_follow_user_api_enabled": True,
            "super_follow_tweet_api_enabled": True,
            "articles_api_enabled": True,
            "android_graphql_skip_api_media_color_palette": True,
            "creator_subscriptions_tweet_preview_api_enabled": True,
            "freedom_of_speech_not_reach_fetch_enabled": True,
            "tweetypie_unmention_optimization_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "subscriptions_verification_info_enabled": True,
            "blue_business_profile_image_shape_enabled": True,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "immersive_video_status_linkable_timestamps": True,
            "super_follow_exclusive_tweet_notifications_enabled": True,
            "unified_cards_ad_metadata_container_dynamic_card_content_query_enabled": True
        }

        payload = {
            "variables": variables,
            "features": features,
            "queryId": query_id,
        }
        
        try:
            response, data = await self.request("POST", url, json=payload)
            
            tweets = []
            if "data" in data:
                instructions = data["data"]["threaded_conversation_with_injections_v2"]["instructions"]
                for instruction in instructions:
                    if instruction["type"] == "TimelineAddEntries":
                        for entry in instruction["entries"]:
                            try:
                                if (entry["content"].get("items") or 
                                    entry["content"].get("itemContent")):
                                    content = entry["content"]
                                    
                                    # Handle both single tweets and tweet groups
                                    if "items" in content:
                                        for item in content["items"]:
                                            if "tweet" in item["item"]["itemContent"]:
                                                tweet_data = item["item"]["itemContent"]["tweet"]["result"]
                                                tweets.append(Tweet.from_raw_data(tweet_data))
                                    elif "itemContent" in content:
                                        if "tweet" in content["itemContent"]:
                                            tweet_data = content["itemContent"]["tweet"]["result"]
                                            tweets.append(Tweet.from_raw_data(tweet_data))
                            except Exception as e:
                                logger.warning(f"Failed to parse entry in conversation: {e}")
                                continue
            
            return tweets
            
        except Exception as e:
            logger.error(f"Error fetching conversation for tweet {tweet_id}: {e}")
            raise

    async def vote(
        self, 
        tweet_id: int | str, 
        card_id: int | str, 
        choice_number: int
    ) -> dict:
        """Vote in a Twitter poll"""
        url = "https://caps.twitter.com/v2/capi/passthrough/1"
        params = {
            "twitter:string:card_uri": f"card://{card_id}",
            "twitter:long:original_tweet_id": str(tweet_id),
            "twitter:string:response_card_name": "poll2choice_text_only",
            "twitter:string:cards_platform": "Web-12",
            "twitter:string:selected_choice": str(choice_number),
        }
        response, response_json = await self.request("POST", url, params=params)
        return response_json

    async def send_message_to_conversation(
        self, 
        conversation_id: int | str, 
        text: str
    ) -> dict:
        """
        Send a message to an existing conversation
        """
        url = f"https://api.twitter.com/2/dm_conversations/{conversation_id}/messages"
        payload = {"text": text}
        response, response_json = await self.request("POST", url, json=payload)
        return response_json["event"]
    
    #twitter/client.py - Add these methods to the Client class
    async def get_tweet_details(self, tweet_id: str | int) -> Tweet:
        """
        Get detailed tweet information using TweetResultByIdQuery
        
        Args:
            tweet_id: The ID of the tweet to fetch
            
        Returns:
            Tweet: Tweet object with detailed information
        """
        url, query_id = self._action_to_url("TweetResultByIdQuery")
        
        variables = {
            "includeTweetImpression": True,
            "includeHasBirdwatchNotes": True,
            "includeEditPerspective": False,
            "includeEditControl": True,
            "includeCommunityTweetRelationship": True,
            "rest_id": str(tweet_id),
            "includeTweetVisibilityNudge": True
        }
        
        features = {
            "longform_notetweets_inline_media_enabled": True,
            "super_follow_badge_privacy_enabled": True,
            "longform_notetweets_rich_text_read_enabled": True,
            "super_follow_user_api_enabled": True,
            "super_follow_tweet_api_enabled": True,
            "articles_api_enabled": True,
            "android_graphql_skip_api_media_color_palette": True,
            "creator_subscriptions_tweet_preview_api_enabled": True,
            "freedom_of_speech_not_reach_fetch_enabled": True,
            "tweetypie_unmention_optimization_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "subscriptions_verification_info_enabled": True,
            "blue_business_profile_image_shape_enabled": True,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "immersive_video_status_linkable_timestamps": True,
            "super_follow_exclusive_tweet_notifications_enabled": True
        }
        
        params = {
            "variables": variables,
            "features": features,
        }

        # Add required headers for this specific endpoint

        try:
            response, data = await self.request(
                "GET", 
                url, 
                params=params,
            )
            
            if not data or "data" not in data:
                raise TwitterException(f"Failed to fetch tweet {tweet_id}")
            
            tweet_result = data["data"]["tweet_result"]["result"]
            
            # Parse additional data that might be useful
            tweet = Tweet.from_raw_data(tweet_result)
            
            # Add view count if available
            if "view_count_info" in tweet_result:
                tweet.view_count = int(tweet_result["view_count_info"]["count"])
            
            # Add edit control info if available
            if "edit_control" in tweet_result:
                tweet.edit_control = tweet_result["edit_control"]
            
            return tweet

        except Exception as e:
            logger.error(f"Failed to fetch tweet details for {tweet_id}: {e}")
            raise

    async def reply(
        self,
        tweet_id: str | int,
        text: str,
        *,
        media_id: int | str = None,
        search_duplicate: bool = True,
    ) -> Tweet:
        """
        Reply to a tweet
        """
        url, query_id = self._action_to_url("CreateTweet")
        variables = {
            "tweet_text": text,
            "reply": {
                "in_reply_to_tweet_id": str(tweet_id),
                "exclude_reply_user_ids": [],
            },
            "dark_request": False,
            "media": {"media_entities": [], "possibly_sensitive": False},
            "semantic_annotation_ids": [],
        }
        
        if media_id:
            variables["media"]["media_entities"].append(
                {"media_id": str(media_id), "tagged_users": []}
            )

        features = {
            "responsive_web_twitter_article_tweet_consumption_enabled": True,
            "longform_notetweets_inline_media_enabled": True,
            "creator_subscriptions_quote_tweet_preview_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "view_counts_everywhere_api_enabled": True,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "tweet_awards_web_tipping_enabled": True,
            "tweetypie_unmention_optimization_enabled": True,
            "rweb_tipjar_consumption_enabled": True,
            "c9s_tweet_anatomy_moderator_badge_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_edit_tweet_api_enabled": True,
            "verified_phone_label_enabled": False,
            "rweb_video_timestamps_enabled": True,
            "communities_web_enable_tweet_community_results_fetch": True,
            "responsive_web_graphql_exclude_directive_enabled": True,
            "freedom_of_speech_not_reach_fetch_enabled": True,
            "responsive_web_enhance_cards_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
            "longform_notetweets_rich_text_read_enabled": True,
            "standardized_nudges_misinfo": True,
            "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
            "articles_preview_enabled": True
        }

        payload = {
            "variables": variables,
            "features": features,
            "queryId": query_id,
        }
        
        response, data = await self.request("POST", url, json=payload)
        return Tweet.from_raw_data(data["data"]["create_tweet"]["tweet_results"]["result"])

    async def quote(
        self,
        tweet_url: str,
        text: str,
        *,
        media_id: int | str = None,
        search_duplicate: bool = True,
    ) -> Tweet:
        """
        Quote a tweet with additional text
        """
        url, query_id = self._action_to_url("CreateTweet")
        variables = {
            "tweet_text": text,
            "attachment_url": tweet_url,
            "dark_request": False,
            "media": {"media_entities": [], "possibly_sensitive": False},
            "semantic_annotation_ids": [],
        }
        
        if media_id:
            variables["media"]["media_entities"].append(
                {"media_id": str(media_id), "tagged_users": []}
            )

        # Same features as reply
        features = {
            "responsive_web_twitter_article_tweet_consumption_enabled": True,
            "longform_notetweets_inline_media_enabled": True,
            "creator_subscriptions_quote_tweet_preview_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "view_counts_everywhere_api_enabled": True,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "tweet_awards_web_tipping_enabled": True,
            "tweetypie_unmention_optimization_enabled": True,
            "rweb_tipjar_consumption_enabled": True,
            "c9s_tweet_anatomy_moderator_badge_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_edit_tweet_api_enabled": True,
            "verified_phone_label_enabled": False,
            "rweb_video_timestamps_enabled": True,
            "communities_web_enable_tweet_community_results_fetch": True,
            "responsive_web_graphql_exclude_directive_enabled": True,
            "freedom_of_speech_not_reach_fetch_enabled": True,
            "responsive_web_enhance_cards_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
            "longform_notetweets_rich_text_read_enabled": True,
            "standardized_nudges_misinfo": True,
            "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
            "articles_preview_enabled": True
        }

        payload = {
            "variables": variables,
            "features": features,
            "queryId": query_id,
        }
        
        response, data = await self.request("POST", url, json=payload)
        return Tweet.from_raw_data(data["data"]["create_tweet"]["tweet_results"]["result"])

    async def like(self, tweet_id: int) -> bool:
        """
        Like a tweet
        """
        url, query_id = self._action_to_url("FavoriteTweet")
        json_payload = {
            "variables": {"tweet_id": str(tweet_id)},
            "queryId": query_id,
        }
        response, data = await self.request("POST", url, json=json_payload)
        print(response)
        return data["data"]["favorite_tweet"] == "Done"

    async def unlike(self, tweet_id: int) -> bool:
        """
        Unlike a tweet
        """
        url, query_id = self._action_to_url("UnfavoriteTweet")
        json_payload = {
            "variables": {"tweet_id": str(tweet_id)},
            "queryId": query_id,
        }
        response, data = await self.request("POST", url, json=json_payload)
        return data["data"]["unfavorite_tweet"] == "Done"

    async def retweet(self, tweet_id: int) -> bool:
        """
        retweet a tweet
        """
        url, query_id = self._action_to_url("CreateRetweet")
        json_payload = {
            "variables": {"tweet_id": str(tweet_id)},
            "queryId": query_id,
        }
        response, data = await self.request("POST", url, json=json_payload)
        print(response,data)
        return data
    async def timeline(self,) -> dict:
        """
        get timeline  tweet
        """
        url, query_id = self._action_to_url("HomeTimeline")
        variables = {
            "count" : 40,
            "cursor" : None,
            "includePromotedContent" : True,
            "latestControlAvailable" : True,
            "requestContext" : "ptr",
            "withCommunity": True,
        }
        
        features = {
            "articles_preview_enabled": True ,
            "c9s_tweet_anatomy_moderator_badge_enabled": True ,
            "communities_web_enable_tweet_community_results_fetch": True ,
            "creator_subscriptions_quote_tweet_preview_enabled": False ,
            "creator_subscriptions_tweet_preview_api_enabled": True ,
            "freedom_of_speech_not_reach_fetch_enabled": True ,
            "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True ,
            "longform_notetweets_consumption_enabled": True ,
            "longform_notetweets_inline_media_enabled": True ,
            "longform_notetweets_rich_text_read_enabled": True ,
            "premium_content_api_read_enabled": False ,
            "profile_label_improvements_pcf_label_in_post_enabled": False ,
            "responsive_web_edit_tweet_api_enabled": True ,
            "responsive_web_enhance_cards_enabled": False ,
            "responsive_web_graphql_exclude_directive_enabled": True ,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False ,
            "responsive_web_graphql_timeline_navigation_enabled": True ,
            "responsive_web_grok_analyze_button_fetch_trends_enabled": True ,
            "responsive_web_twitter_article_tweet_consumption_enabled": True ,
            "rweb_tipjar_consumption_enabled": True ,
            "rweb_video_timestamps_enabled": True ,
            "standardized_nudges_misinfo": True ,
            "tweet_awards_web_tipping_enabled": False ,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True ,
            "verified_phone_label_enabled": False ,
            "view_counts_everywhere_api_enabled": True ,
            }
        
        params = {
            "variables": variables,
            "features": features,
            "queryId": query_id,
        }
        response, data = await self.request("GET", url, params=params)
        print(response,data)
        return data
    
    async def delete_tweet(self, tweet_id: int | str) -> bool:
        """
        Delete a tweet
        """
        url, query_id = self._action_to_url("DeleteTweet")
        json_payload = {
            "variables": {
                "tweet_id": str(tweet_id),
                "dark_request": False,
            },
            "queryId": query_id,
        }
        response, data = await self.request("POST", url, json=json_payload)
        return "data" in data and "delete_tweet" in data["data"]

    async def request_tweet(self, tweet_id: int | str) -> Tweet:
        """
        Get tweet details by ID
        """
        url, query_id = self._action_to_url("TweetResultByRestId")
        variables = {
            "tweetId": str(tweet_id),
            "withCommunity": True,
            "includePromotedContent": False,
            "withVoice": True,
        }
        features = {
            "creator_subscriptions_tweet_preview_api_enabled": True,
            "longform_notetweets_consumption_enabled": True,
            "longform_notetweets_inline_media_enabled": True,
            "responsive_web_edit_tweet_api_enabled": True,
            "responsive_web_enhance_cards_enabled": False,
            "responsive_web_graphql_exclude_directive_enabled": True,
            "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "responsive_web_graphql_timeline_navigation_enabled": True,
            "responsive_web_twitter_article_tweet_consumption_enabled": False,
            "tweet_awards_web_tipping_enabled": False,
            "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
            "tweetypie_unmention_optimization_enabled": True,
            "verified_phone_label_enabled": False,
            "view_counts_everywhere_api_enabled": True,
        }
        params = {
            "variables": variables,
            "features": features,
        }
        response, data = await self.request("GET", url, params=params)
        if not data or "data" not in data:
            raise TwitterException(f"Failed to fetch tweet {tweet_id}")
            
        tweet_data = data["data"]["tweetResult"]["result"]
        return Tweet.from_raw_data(tweet_data)

    async def send_message(self, user_id: int | str, text: str) -> dict:
        """
        Send a direct message to a user
        """
        url = "https://api.twitter.com/1.1/direct_messages/events/new.json"
        payload = {
            "event": {
                "type": "message_create",
                "message_create": {
                    "target": {"recipient_id": str(user_id)},
                    "message_data": {"text": text},
                },
            }
        }
        response, data = await self.request("POST", url, json=payload)
        return data["event"]

    async def follow_multiple(self, user_ids: list[int | str]) -> dict[int, bool]:
        """
        Follow multiple users at once and return success status for each
        """
        results = {}
        for user_id in user_ids:
            try:
                success = await self.follow(user_id)
                results[user_id] = success
            except Exception as e:
                logger.error(f"Failed to follow user {user_id}: {e}")
                results[user_id] = False
        return results

    async def unfollow_multiple(self, user_ids: list[int | str]) -> dict[int, bool]:
        """
        Unfollow multiple users at once and return success status for each
        """
        results = {}
        for user_id in user_ids:
            try:
                success = await self.unfollow(user_id)
                results[user_id] = success
            except Exception as e:
                logger.error(f"Failed to unfollow user {user_id}: {e}")
                results[user_id] = False
        return results

class GQLClient:
    _GRAPHQL_URL = "https://x.com/i/api/graphql"
    _OPERATION_TO_QUERY_ID = {
        "CreateRetweet": "ojPdsZsimiJrUGLR1sjUtA",
        "FavoriteTweet": "lI07N6Otwv1PhnEgXILM7A",
        "UnfavoriteTweet": "ZYKSe-w7KEslx3JhSIk5LA",
        "CreateTweet": "v0en1yVV-Ybeek8ClmXwYw",
        "TweetResultByRestId": "Xl5pC_lBk_gcO2ItU39DQw",
        "ModerateTweet": "p'jF:GVqCjTcZol0xcBJjw",
        "DeleteTweet": "VaenaVgh5q5ih7kvyVjgtg",
        "UserTweets": "V1ze5q3ijDS1VeLwLY0m7g",
        "TweetDetail": "VWFGPVAGkZMGRKGe3GFFnA",
        "ProfileSpotlightsQuery": "9zwVLJ48lmVUk8u_Gh9DmA",
        "Following": "t-BPOrMIduGUJWO_LxcvNQ",
        "Followers": "3yX7xr2hKjcZYnXt6cU6lQ",
        "UserByScreenName": "G3KGOASz96M-Qu0nwmGXNg",
        "UsersByRestIds": "itEhGywpgX9b3GJCzOtSrA",
        "Viewer": "-876iyxD1O_0X0BqeykjZA",
        "HomeTimeline": "Iaj4kAIobIAtigNaYNIOAw"
    }
    _DEFAULT_VARIABLES = {
        "count": 1000,
        "withSafetyModeUserFields": True,
        "includePromotedContent": True,
        "withQuickPromoteEligibilityTweetFields": True,
        "withVoice": True,
        "withV2Timeline": True,
        "withDownvotePerspective": False,
        "withBirdwatchNotes": True,
        "withCommunity": True,
        "withSuperFollowsUserFields": True,
        "withReactionsMetadata": False,
        "withReactionsPerspective": False,
        "withSuperFollowsTweetFields": True,
        "isMetatagsQuery": False,
        "withReplays": True,
        "withClientEventToken": False,
        "withAttachments": True,
        "withConversationQueryHighlights": True,
        "withMessageQueryHighlights": True,
        "withMessages": True,
    }
    _DEFAULT_FEATURES = {
        'tweetypie_unmention_optimization_enabled': True,
        'responsive_web_media_download_video_enabled': False,
        'creator_subscriptions_tweet_preview_api_enabled': True,
        'communities_web_enable_tweet_community_results_fetch': True,
        'c9s_tweet_anatomy_moderator_badge_enabled': True,
        'responsive_web_edit_tweet_api_enabled': True,
        'graphql_is_translatable_rweb_tweet_is_translatable_enabled': True,
        'view_counts_everywhere_api_enabled': True,
        'longform_notetweets_consumption_enabled': True,
        'responsive_web_twitter_article_tweet_consumption_enabled': True,
        'tweet_awards_web_tipping_enabled': False,
        'creator_subscriptions_quote_tweet_preview_enabled': False,
        'longform_notetweets_rich_text_read_enabled': True,
        'longform_notetweets_inline_media_enabled': True,
        'articles_preview_enabled': True,
        'rweb_video_timestamps_enabled': False,
        'rweb_tipjar_consumption_enabled': True,
        'responsive_web_graphql_exclude_directive_enabled': True,
        'verified_phone_label_enabled': False,
        'freedom_of_speech_not_reach_fetch_enabled': True,
        'standardized_nudges_misinfo': True,
        'tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled': True,
        'responsive_web_graphql_skip_user_profile_image_extensions_enabled': False,
        'responsive_web_graphql_timeline_navigation_enabled': True,
        'responsive_web_enhance_cards_enabled': False
    }

    @classmethod
    def _operation_to_url(cls, operation: str) -> tuple[str, str]:
        """
        :return: URL and Query ID
        """
        query_id = cls._OPERATION_TO_QUERY_ID[operation]
        url = f"{cls._GRAPHQL_URL}/{query_id}/{operation}"
        return url, query_id

    def __init__(self, client: Client):
        self._client = client

    async def gql_request(
        self, method, operation, **kwargs
    ) -> tuple[requests.Response, dict]:
        url, query_id = self._operation_to_url(operation)

        if method == "POST":
            payload = kwargs["json"] = kwargs.get("json") or {}
            payload["queryId"] = query_id
        else:
            params = kwargs["params"] = kwargs.get("params") or {}
            ...

        response, data = await self._client.request(method, url, **kwargs)
        return response, data["data"]

    async def user_by_username(self, username: str) -> User | None:
        features = self._DEFAULT_FEATURES
        variables = self._DEFAULT_VARIABLES
        variables["screen_name"] = username
        params = {
            "variables": variables,
            "features": features,
        }
        response, data = await self.gql_request(
            "GET", "UserByScreenName", params=params
        )
        return User.from_raw_data(data["user"]["result"]) if data else None

    async def users_by_ids(
        self, user_ids: Iterable[str | int]
    ) -> dict[int : User | Account]:
        features = self._DEFAULT_FEATURES
        variables = self._DEFAULT_VARIABLES
        variables["userIds"] = list({str(user_id) for user_id in user_ids})
        params = {
            "variables": variables,
            "features": features,
        }
        response, data = await self.gql_request("GET", "UsersByRestIds", params=params)

        users = {}
        for user_data in data["users"]:
            user = User.from_raw_data(user_data["result"])
            users[user.id] = user
            if user.id == self._client.account.id:
                users[self._client.account.id] = self._client.account
        return users