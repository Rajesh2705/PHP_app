import json
from typing import Optional, Any
from datetime import datetime
from loguru import logger
from pydantic import BaseModel, Field
from .utils import to_datetime, tweet_url

class User(BaseModel):
    # fmt: off
    id:              int      | None = None
    username:        str      | None = None
    name:            str      | None = None  # 50
    created_at:      datetime | None = None
    description:     str      | None = ""    # Make description optional with default empty string
    location:        str      | None = ""    # Make location optional with default empty string
    followers_count: int      | None = 0     # Make counts optional with default 0
    friends_count:   int      | None = 0
    raw_data:        dict     | None = None
    # fmt: on

    def __str__(self):
        return str(self.id)

    def __repr__(self):
        return f"{self.__class__.__name__}(id={self.id}, username={self.username})"

    def __hash__(self):
        return hash(self.id)

    @classmethod
    def from_raw_data(cls, data: dict):
        legacy = data["legacy"]
        # Use get() method with defaults for optional fields
        values = {
            "name": legacy.get("name", ""),
            "description": legacy.get("description", ""),
            "location": legacy.get("location", ""),
            "followers_count": legacy.get("followers_count", 0),
            "friends_count": legacy.get("friends_count", 0)
        }
        values.update(
            {
                "id": int(data["rest_id"]),
                "username": legacy["screen_name"],
                "created_at": to_datetime(legacy.get("created_at", "")),
                "raw_data": data,
            }
        )
        return cls(**values)

class VideoVariant(BaseModel):
    url: str
    content_type: str
    bitrate: Optional[int] = None

class VideoInfo(BaseModel):
    aspect_ratio: list[int]
    duration_millis: Optional[int] = None
    variants: list[VideoVariant]

class Media(BaseModel):
    type: str
    url: Optional[str] = None
    display_url: Optional[str] = None
    expanded_url: Optional[str] = None
    media_url_https: Optional[str] = None
    video_info: Optional[VideoInfo] = None
    original_info: Optional[dict] = None
    sizes: Optional[dict] = None
    indices: Optional[list[int]] = None
    media_key: Optional[str] = None
    ext_media_availability: Optional[dict] = None
    additional_media_info: Optional[dict] = None
    features: Optional[dict] = None
    id_str: Optional[str] = None

class NoteTweet(BaseModel):
    id: str
    text: str
    entity_set: dict
    richtext: Optional[dict] = None
    media: Optional[dict] = None

class Note(BaseModel):
    note_tweet_results: dict
    is_expandable: bool

class EditControl(BaseModel):
    edit_tweet_ids: list[str]
    editable_until_msecs: str
    edits_remaining: str
    is_edit_eligible: bool

class TweetStats(BaseModel):
    quote_count: int = 0
    retweet_count: int = 0
    bookmark_count: int = 0
    favorite_count: int = 0
    reply_count: int = 0
    view_count: Optional[int] = None

class Card(BaseModel):
    rest_id: Optional[str] = None
    legacy: Optional[dict] = None

class Tweet(BaseModel):
    # Basic tweet info
    id: int
    text: str
    language: str
    created_at: datetime
    conversation_id: int
    
    # States
    quoted: bool = False
    retweeted: bool = False
    bookmarked: bool = False
    favorited: bool = False
    possibly_sensitive: bool = False
    possibly_sensitive_editable: bool = False
    
    # Stats
    quote_count: int = 0
    retweet_count: int = 0
    bookmark_count: int = 0
    favorite_count: int = 0
    reply_count: int = 0
    view_count: Optional[int] = None
    
    # Related tweets
    quoted_tweet: Optional["Tweet"] = None
    retweeted_tweet: Optional["Tweet"] = None
    replies: list["Tweet"] = Field(default_factory=list)
    in_reply_to_status_id: Optional[int] = None
    in_reply_to_user_id: Optional[int] = None
    in_reply_to_screen_name: Optional[str] = None
    
    # Display info
    pinned: bool = False
    display_type: Optional[str] = None
    social_context: Optional[str] = None
    url: str
    source: Optional[str] = None
    card: Optional[Card] = None
    
    # User info
    user: User
    
    # Media
    media: list[Media] = Field(default_factory=list)
    
    # Additional data
    social_context: Optional[str] = None
    note_tweet: Optional[Note] = None
    edit_control: Optional[EditControl] = None
    display_text_range: Optional[list[int]] = None
    entities: Optional[dict] = None
    extended_entities: Optional[dict] = None
    limited_actions: Optional[list[str]] = None
    has_birdwatch_notes: bool = False
    raw_data: dict

    def __str__(self):
        return f"Tweet(id={self.id}, text={self.short_text})"

    def __repr__(self):
        return f"{self.__class__.__name__}(id={self.id}, text={self.short_text}, user_id={self.user.id})"

    @property
    def short_text(self) -> str:
        return f"{self.text[:32]}..." if len(self.text) > 32 else self.text

    def get_highest_quality_video(self) -> Optional[str]:
        """Get the URL of the highest quality video variant"""
        for media in self.media:
            if media.video_info:
                sorted_variants = sorted(
                    [v for v in media.video_info.variants if v.bitrate],
                    key=lambda x: x.bitrate,
                    reverse=True
                )
                if sorted_variants:
                    return sorted_variants[0].url
        return None

    @classmethod
    def from_raw_data(cls, data: dict):
        try:
            # Handle TweetWithVisibilityResults wrapper
            if data.get("__typename") == "TweetWithVisibilityResults" and "tweet" in data:
                data = data["tweet"]
            
            legacy_data = data.get("legacy", data)
            
            # Get tweet ID
            tweet_id = int(data.get("rest_id") or legacy_data.get("id_str") or legacy_data["id"])
            
            # Improved user data handling
            user_result = None
            if "core" in data and "user_results" in data["core"]:
                user_result = data["core"]["user_results"].get("result")
            elif "core" in data and "user_result" in data["core"]:
                user_result = data["core"]["user_result"].get("result")
            elif "user" in legacy_data:
                user_result = {
                    "rest_id": str(legacy_data["user"]["id"]),
                    "legacy": legacy_data["user"]
                }
                
            if not user_result:
                user_id = legacy_data.get("user_id_str")
                if not user_id and "in_reply_to_status_id_str" in legacy_data:
                    # Handle reply cases
                    user_id = legacy_data.get("in_reply_to_user_id_str")
                    screen_name = legacy_data.get("in_reply_to_screen_name")
                else:
                    user_id = legacy_data.get("user_id_str")
                    screen_name = None

                user_result = {
                    "rest_id": user_id,
                    "legacy": {
                        "id_str": user_id,
                        "screen_name": screen_name or legacy_data.get("screen_name", "unknown"),
                        "name": legacy_data.get("name", "Unknown User"),
                        "created_at": legacy_data.get("created_at", ""),
                    }
                }

            # Create user object
            user = User.from_raw_data(user_result)
            url = tweet_url(user.username, tweet_id)
            
            # Build base values
            values = {
                "id": tweet_id,
                "text": legacy_data.get("full_text", legacy_data.get("text", "")),
                "language": legacy_data.get("lang", "unknown"),
                "created_at": to_datetime(legacy_data.get("created_at", "")),
                "conversation_id": int(legacy_data.get("conversation_id_str", str(tweet_id))),
                "source": legacy_data.get("source"),
                
                # Tweet states
                "quoted": legacy_data.get("is_quote_status", False),
                "retweeted": legacy_data.get("retweeted", False),
                "bookmarked": legacy_data.get("bookmarked", False),
                "favorited": legacy_data.get("favorited", False),
                "possibly_sensitive": legacy_data.get("possibly_sensitive", False),
                "possibly_sensitive_editable": legacy_data.get("possibly_sensitive_editable", False),
                
                # Stats
                "quote_count": legacy_data.get("quote_count", 0),
                "retweet_count": legacy_data.get("retweet_count", 0),
                "bookmark_count": legacy_data.get("bookmark_count", 0),
                "favorite_count": legacy_data.get("favorite_count", 0),
                "reply_count": legacy_data.get("reply_count", 0),
                
                # Reply info
                "in_reply_to_status_id": legacy_data.get("in_reply_to_status_id_str"),
                "in_reply_to_user_id": legacy_data.get("in_reply_to_user_id_str"),
                "in_reply_to_screen_name": legacy_data.get("in_reply_to_screen_name"),
                
                # Core data
                "user": user,
                "url": url,
                "entities": legacy_data.get("entities"),
                "extended_entities": legacy_data.get("extended_entities"),
                "display_text_range": legacy_data.get("display_text_range"),
                "has_birdwatch_notes": data.get("has_birdwatch_notes", False),
                
                # Store raw data
                "raw_data": data,
            }
            
            # Add view count
            if "view_count_info" in data:
                try:
                    values["view_count"] = int(data["view_count_info"].get("count", 0))
                except (TypeError, ValueError):
                    pass

            # Add edit control
            if "edit_control" in data:
                try:
                    values["edit_control"] = EditControl(**data["edit_control"])
                except Exception as e:
                    logger.warning(f"Failed to parse edit control: {e}")

            # Add note tweet
            if "note_tweet" in data:
                try:
                    values["note_tweet"] = Note(**data["note_tweet"])
                except Exception as e:
                    logger.warning(f"Failed to parse note tweet: {e}")
            
            # Add card if present
            if "card" in data:
                try:
                    values["card"] = Card(**data["card"])
                except Exception as e:
                    logger.warning(f"Failed to parse card: {e}")

            # Add limited actions
            if "limitedActionResults" in data:
                try:
                    values["limited_actions"] = [
                        action["action"] 
                        for action in data["limitedActionResults"]["limited_actions"]
                    ]
                except Exception as e:
                    logger.warning(f"Failed to parse limited actions: {e}")
            
            # Add media
            media_list = []
            if "extended_entities" in legacy_data and "media" in legacy_data["extended_entities"]:
                for media_item in legacy_data["extended_entities"]["media"]:
                    try:
                        media_list.append(Media(**media_item))
                    except Exception as e:
                        logger.warning(f"Failed to parse media item: {e}")
            values["media"] = media_list
                    
            # Handle quoted tweet
            if ("quoted_status_result" in data and 
                data["quoted_status_result"].get("result")):
                quoted_tweet_data = data["quoted_status_result"]["result"]
                try:
                    values["quoted_tweet"] = cls.from_raw_data(quoted_tweet_data)
                except Exception as e:
                    logger.warning(f"Failed to parse quoted tweet: {e}")
                
            # Handle retweeted tweet
            if ("retweeted_status_result" in legacy_data and 
                legacy_data["retweeted_status_result"].get("result")):
                retweeted_tweet_data = legacy_data["retweeted_status_result"]["result"]
                try:
                    values["retweeted_tweet"] = cls.from_raw_data(retweeted_tweet_data)
                except Exception as e:
                    logger.warning(f"Failed to parse retweeted tweet: {e}")
            
            return cls(**values)
            
        except Exception as e:
            logger.error(f"Error parsing tweet data: {e}\nData: {json.dumps(data, indent=2)}")
            raise ValueError(f"Failed to parse tweet data: {e}") from e

# Rebuild model to handle self-referential types
Tweet.model_rebuild()

class Image(BaseModel):
    type: str = Field(..., alias="image_type")
    width: int = Field(..., alias="w")
    height: int = Field(..., alias="h")