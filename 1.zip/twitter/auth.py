# twitter/auth.py
import time
import hmac
import base64
import random
import string
from hashlib import sha1
from urllib.parse import quote, urlencode

class TwitterAuth:
    def __init__(
        self,
        consumer_key: str,
        consumer_secret: str,
        access_token: str = None,
        access_token_secret: str = None
    ):
        self.consumer_key = consumer_key
        self.consumer_secret = consumer_secret
        self.access_token = access_token
        self.access_token_secret = access_token_secret

    def _percent_encode(self, string: str) -> str:
        return quote(string, safe='~').replace("'", '%27')

    def _generate_nonce(self, length: int = 32) -> str:
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    def _generate_signature(self, method: str, url: str, params: dict) -> str:
        # Create signature base string
        param_string = '&'.join(f"{k}={self._percent_encode(str(v))}" 
                              for k, v in sorted(params.items()))
        
        base_string = '&'.join(self._percent_encode(s) for s in [
            method.upper(),
            url,
            param_string
        ])

        # Create signing key
        signing_key = '&'.join([
            self._percent_encode(self.consumer_secret),
            self._percent_encode(self.access_token_secret or '')
        ])

        # Generate signature
        hashed = hmac.new(
            signing_key.encode('utf-8'),
            base_string.encode('utf-8'),
            sha1
        )
        
        return base64.b64encode(hashed.digest()).decode('utf-8')

    def get_auth_headers(self, method: str, url: str, params: dict = None) -> dict:
        """Generate OAuth1 headers for a request"""
        oauth_params = {
            'oauth_consumer_key': self.consumer_key,
            'oauth_nonce': self._generate_nonce(),
            'oauth_signature_method': 'HMAC-SHA1',
            'oauth_timestamp': str(int(time.time())),
            'oauth_version': '1.0'
        }
        
        if self.access_token:
            oauth_params['oauth_token'] = self.access_token

        # Combine parameters
        all_params = {}
        if params:
            all_params.update(params)
        all_params.update(oauth_params)

        # Generate signature
        oauth_params['oauth_signature'] = self._generate_signature(method, url, all_params)

        # Create Authorization header
        auth_header = 'OAuth ' + ', '.join(
            f'{self._percent_encode(k)}="{self._percent_encode(v)}"'
            for k, v in sorted(oauth_params.items())
        )

        return {'Authorization': auth_header}